package com.mindtree.ShoppingKartManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.ShoppingKartManagementSystem.entity.Category;

@Repository
public interface CategoryRepository extends JpaRepositoryImplementation<Category, Integer>{

	public Category findByCategoryName(String categoryName);
}
