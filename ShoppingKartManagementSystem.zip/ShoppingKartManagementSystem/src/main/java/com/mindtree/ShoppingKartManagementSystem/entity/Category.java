package com.mindtree.ShoppingKartManagementSystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int categoryId;

	private String categoryName;

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.REFRESH }, mappedBy = "category")
	private List<Brand> brand;

	public Category() {
		super();
	}

	public Category(int categoryId, String categoryName, List<Brand> brand) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.brand = brand;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<Brand> getBrand() {
		return brand;
	}

	public void setBrand(List<Brand> brand) {
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + ", brand=" + brand + "]";
	}

}
