package com.mindtree.ShoppingKartManagementSystem.service;

import java.util.List;

import com.mindtree.ShoppingKartManagementSystem.dto.BrandDto;
import com.mindtree.ShoppingKartManagementSystem.dto.CategoryDto;
import com.mindtree.ShoppingKartManagementSystem.dto.ProductDto;

public interface CategoryBrandProductService {

	public List<CategoryDto> getAllCategory();
	
	public List<BrandDto> getBrandsFromCategoryFromDB(String categoryName);
	
	public List<ProductDto> getProductsFromBrandFromDB(String brandName);
}
