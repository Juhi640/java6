package com.mindtree.ShoppingKartManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.ShoppingKartManagementSystem.dto.BrandDto;
import com.mindtree.ShoppingKartManagementSystem.dto.CategoryDto;
import com.mindtree.ShoppingKartManagementSystem.dto.ProductDto;
import com.mindtree.ShoppingKartManagementSystem.service.CategoryBrandProductService;

@Controller
public class AppController {

	@Autowired
	private CategoryBrandProductService categorybrandproductservice;

	@RequestMapping("/")
	public String login(Model model) {
		List<CategoryDto> categoriesdto = categorybrandproductservice.getAllCategory();
		model.addAttribute("categoriesdto", categoriesdto);
		return "login";
	}

	@RequestMapping("/getbrands/{categoryName}")
	public String getAllBrandsFromCategory(@PathVariable String categoryName, Model model) {
		List<BrandDto> brandsdto = categorybrandproductservice.getBrandsFromCategoryFromDB(categoryName);
		model.addAttribute("brandsdto", brandsdto);
		return "view";
	}

	@RequestMapping("/getbrands/getproducts/{brandName}")
	public String getAllProductsFromBrand(@PathVariable  String brandName, Model model) {
		List<ProductDto> productsdto = categorybrandproductservice.getProductsFromBrandFromDB(brandName);
		model.addAttribute("productsdto", productsdto);
		return "display";
	}
}
