package com.mindtree.ShoppingKartManagementSystem.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class ProductDto {

	private int productId;

	private String productName;

	private int price;

	private String color;

	@JsonIgnoreProperties("productdto")
	private BrandDto branddto;

	public ProductDto() {
		super();
	}

	public ProductDto(int productId, String productName, int price, String color, BrandDto branddto) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.color = color;
		this.branddto = branddto;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public BrandDto getBranddto() {
		return branddto;
	}

	public void setBranddto(BrandDto branddto) {
		this.branddto = branddto;
	}

	@Override
	public String toString() {
		return "ProductDto [productId=" + productId + ", productName=" + productName + ", price=" + price + ", color="
				+ color + ", branddto=" + branddto + "]";
	}

}
