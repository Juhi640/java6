package com.mindtree.ShoppingKartManagementSystem.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class CategoryDto {

	private int categoryId;

	private String categoryName;

	@JsonIgnoreProperties("categorydto")
	private List<BrandDto> branddto;

	public CategoryDto() {
		super();
	}

	public CategoryDto(int categoryId, String categoryName, List<BrandDto> branddto) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.branddto = branddto;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<BrandDto> getBranddto() {
		return branddto;
	}

	public void setBranddto(List<BrandDto> branddto) {
		this.branddto = branddto;
	}

	@Override
	public String toString() {
		return "CategoryDto [categoryId=" + categoryId + ", categoryName=" + categoryName + ", branddto=" + branddto
				+ "]";
	}

}
