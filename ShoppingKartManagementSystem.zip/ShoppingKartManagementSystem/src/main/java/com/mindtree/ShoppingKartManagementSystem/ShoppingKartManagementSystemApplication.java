package com.mindtree.ShoppingKartManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingKartManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingKartManagementSystemApplication.class, args);
	}

}
