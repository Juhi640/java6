package com.mindtree.ShoppingKartManagementSystem.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class BrandDto {

	private int brandId;

	private String brandName;

	@JsonIgnoreProperties("brandto")
	private List<CategoryDto> categorydto;

	@JsonIgnoreProperties("brandto")
	List<ProductDto> productdto;

	public BrandDto() {
		super();
	}

	public BrandDto(int brandId, String brandName, List<CategoryDto> categorydto, List<ProductDto> productdto) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.categorydto = categorydto;
		this.productdto = productdto;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public List<CategoryDto> getCategorydto() {
		return categorydto;
	}

	public void setCategorydto(List<CategoryDto> categorydto) {
		this.categorydto = categorydto;
	}

	public List<ProductDto> getProductdto() {
		return productdto;
	}

	public void setProductdto(List<ProductDto> productdto) {
		this.productdto = productdto;
	}

	@Override
	public String toString() {
		return "BrandDto [brandId=" + brandId + ", brandName=" + brandName + ", categorydto=" + categorydto
				+ ", productdto=" + productdto + "]";
	}

}
