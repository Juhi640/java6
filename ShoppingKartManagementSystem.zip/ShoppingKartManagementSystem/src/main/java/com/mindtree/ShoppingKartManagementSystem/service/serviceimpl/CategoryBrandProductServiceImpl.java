package com.mindtree.ShoppingKartManagementSystem.service.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ShoppingKartManagementSystem.dto.BrandDto;
import com.mindtree.ShoppingKartManagementSystem.dto.CategoryDto;
import com.mindtree.ShoppingKartManagementSystem.dto.ProductDto;
import com.mindtree.ShoppingKartManagementSystem.entity.Brand;
import com.mindtree.ShoppingKartManagementSystem.entity.Category;
import com.mindtree.ShoppingKartManagementSystem.entity.Product;
import com.mindtree.ShoppingKartManagementSystem.repository.BrandRepository;
import com.mindtree.ShoppingKartManagementSystem.repository.CategoryRepository;
import com.mindtree.ShoppingKartManagementSystem.repository.ProductRepository;
import com.mindtree.ShoppingKartManagementSystem.service.CategoryBrandProductService;

@Service
public class CategoryBrandProductServiceImpl implements CategoryBrandProductService {

	@Autowired
	private CategoryRepository categoryrepository;

	@Autowired
	private BrandRepository brandrepository;

	@Autowired
	private ProductRepository productrepository;

	@Override
	public List<CategoryDto> getAllCategory() {
		List<Category> categories = categoryrepository.findAll();
		List<CategoryDto> categoriesdto = new ArrayList<>();
		for (Category category : categories) {
			CategoryDto categorydto = new CategoryDto();
			categorydto.setCategoryId(category.getCategoryId());
			categorydto.setCategoryName(category.getCategoryName());
			categoriesdto.add(categorydto);
		}
		return categoriesdto;
	}

	@Override
	public List<BrandDto> getBrandsFromCategoryFromDB(String categoryName) {
		Category category = categoryrepository.findByCategoryName(categoryName);
		List<BrandDto> brandsdto = new ArrayList<>();
				for (Brand brand : category.getBrand()) {
					BrandDto branddto = new BrandDto();
					branddto.setBrandId(brand.getBrandId());
					branddto.setBrandName(brand.getBrandName());
					brandsdto.add(branddto);
				}

			
		return brandsdto;
	}

	@Override
	public List<ProductDto> getProductsFromBrandFromDB(String brandName) {
		List<Brand> brands = brandrepository.findAll();
		List<ProductDto> productsdto = new ArrayList<>();
		for (Brand brand : brands){
			if (brand.getBrandName().equalsIgnoreCase(brandName)){
				for (Product product : brand.getProduct()){
					
					ProductDto productdto = new ProductDto();
					productdto.setProductId(product.getProductId());
					productdto.setProductName(product.getProductName());
					productdto.setColor(product.getColor());
					productdto.setPrice(product.getPrice());
					productsdto.add(productdto);
				}
			}
		}
		return productsdto;
	}

}
