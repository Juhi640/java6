package com.mindtree.ShoppingKartManagementSystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.JoinColumn;

@Entity
public class Brand {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int brandId;

	private String brandName;

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.REFRESH })
	@JoinTable(name = "brand_category", joinColumns = @JoinColumn(name = "brandId"), inverseJoinColumns = @JoinColumn(name = "categoryId"))
	private List<Category> category;

	@OneToMany(mappedBy = "brand", cascade = CascadeType.ALL)
	List<Product> product;

	public Brand() {
		super();
	}

	public Brand(int brandId, String brandName, List<Category> category, List<Product> product) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.category = category;
		this.product = product;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public List<Category> getCategory() {
		return category;
	}

	public void setCategory(List<Category> category) {
		this.category = category;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Brand [brandId=" + brandId + ", brandName=" + brandName + ", category=" + category + ", product="
				+ product + "]";
	}

}
